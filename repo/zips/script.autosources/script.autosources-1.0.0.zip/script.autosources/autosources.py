import xbmc
import xbmcaddon
import xbmcvfs
import os
import json
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom
import shutil
from datetime import datetime

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

SOURCES_XML = xbmcvfs.translatePath("special://home/userdata/sources.xml")
JSON_FILE = os.path.join(ADDON_PATH, "sources.json")
BACKUP_DIR = xbmcvfs.translatePath("special://home/userdata/addon_data/script.autosources/backups")

def log(msg):
    xbmc.log(f"[AutoSourcesSafe] {msg}", xbmc.LOGINFO)

def ensure_backup_dir():
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR, exist_ok=True)

def backup_xml():
    if os.path.exists(SOURCES_XML):
        ensure_backup_dir()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(BACKUP_DIR, f"sources_{ts}.xml")
        shutil.copy2(SOURCES_XML, backup_path)
        log(f"backup created: {backup_path}")

def load_sources():
    if not os.path.exists(JSON_FILE):
        return []
    with open(JSON_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def load_xml():
    if os.path.exists(SOURCES_XML):
        return ET.parse(SOURCES_XML)
    return ET.ElementTree(ET.Element("sources"))

def get_files(root):
    root_elem = root.getroot()
    files = root_elem.find("files")
    if files is None:
        files = ET.SubElement(root_elem, "files")
    return files

def exists(files, name, path):
    for s in files.findall("source"):
        n = s.find("name")
        p = s.find("path")
        if n is not None and p is not None:
            if n.text == name and p.text == path:
                return True
    return False

def add(files, name, path):
    src = ET.SubElement(files, "source")
    ET.SubElement(src, "name").text = name
    ET.SubElement(src, "path").text = path
    ET.SubElement(src, "allowsharing").text = "true"

import xml.dom.minidom as minidom

def save_xml(tree):
    xml_str = ET.tostring(tree.getroot(), encoding="utf-8")

    pretty = minidom.parseString(xml_str).toprettyxml(indent="    ")

    # remove empty lines (minidom adds junk whitespace)
    cleaned = "\n".join([line for line in pretty.split("\n") if line.strip()])

    tmp = SOURCES_XML + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(cleaned)

    os.replace(tmp, SOURCES_XML)

def run():
    log("starting safe sync")

    sources = load_sources()
    tree = load_xml()
    files = get_files(tree)

    backup_xml()

    added = 0
    for item in sources:
        name = item.get("name")
        path = item.get("path")
        if not name or not path:
            continue
        if not exists(files, name, path):
            add(files, name, path)
            added += 1

    save_xml(tree)
    log(f"sync complete. added {added}")

if __name__ == "__main__":
    run()
