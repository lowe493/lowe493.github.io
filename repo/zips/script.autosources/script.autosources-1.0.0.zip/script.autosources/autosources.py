import xbmc
import xbmcaddon
import os
import json
import xml.etree.ElementTree as ET

ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmc.translatePath(ADDON.getAddonInfo('path'))

SOURCE_JSON = os.path.join(ADDON_PATH, "sources.json")
SOURCES_XML = xbmc.translatePath("special://home/userdata/sources.xml")


def log(msg):
    xbmc.log(f"[AutoSources] {msg}", xbmc.LOGINFO)


def is_enabled():
    return ADDON.getSetting("enabled") == "true"


def load_sources():
    if not os.path.exists(SOURCE_JSON):
        log("sources.json not found")
        return []

    with open(SOURCE_JSON, "r", encoding="utf-8") as f:
        return json.load(f)


def load_xml():
    if os.path.exists(SOURCES_XML):
        return ET.parse(SOURCES_XML)
    return ET.ElementTree(ET.Element("sources"))


def get_files_node(root):
    root_elem = root.getroot()
    files = root_elem.find("files")
    if files is None:
        files = ET.SubElement(root_elem, "files")
    return files


def exists(files_node, name, path):
    for s in files_node.findall("source"):
        n = s.find("name")
        p = s.find("path")
        if n is not None and p is not None:
            if n.text == name and p.text == path:
                return True
    return False


def add(files_node, name, path):
    src = ET.SubElement(files_node, "source")
    ET.SubElement(src, "name").text = name
    ET.SubElement(src, "path").text = path
    ET.SubElement(src, "allowsharing").text = "true"


def run():
    if not is_enabled():
        log("disabled in settings")
        return

    log("starting sync...")

    sources = load_sources()
    tree = load_xml()
    files = get_files_node(tree)

    added = 0

    for item in sources:
        name = item.get("name")
        path = item.get("path")

        if not name or not path:
            continue

        if not exists(files, name, path):
            add(files, name, path)
            added += 1

    tree.write(SOURCES_XML, encoding="utf-8", xml_declaration=True)

    log(f"sync complete. added {added} sources")


if __name__ == "__main__":
    run()