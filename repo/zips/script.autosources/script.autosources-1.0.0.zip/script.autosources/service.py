import time
import xbmc
import xbmcaddon
import autosources

# wait for Kodi to finish loading
time.sleep(10)

autosources.run()