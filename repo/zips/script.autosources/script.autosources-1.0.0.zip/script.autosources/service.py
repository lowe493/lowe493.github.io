import sys
import time
import xbmcvfs

addon_path = xbmcvfs.translatePath("special://home/addons/script.autosources")
sys.path.append(addon_path)

import autosources

time.sleep(5)
autosources.run()
